import random
dado1 = random.randint(1, 6)
dado2 = random.randint(1, 6)
soma = dado1 + dado2

print(f"Você tirou {dado1} + {dado2} = {soma}")

if soma == 7 or soma == 11:
    print(f"Você tirou {soma}, sendo ele um Natural! Você venceu.")
elif soma == 2 or soma == 3 or soma == 12:
    print(f"Você tirou {soma}, sendo ele um Craps! Você perdeu.")
else:
    ponto = soma
    print(f"Seu ponto é {ponto}.")
    while True:
        dado1 = random.randint(1, 6)
        dado2 = random.randint(1, 6)
        soma = dado1 + dado2
        print(f"Você tirou {dado1} + {dado2} = {soma}")
        if soma == ponto:
            print("Você fez o ponto! Você ganhou.")
            break
        elif soma == 7:
            print("Você tirou 7 antes do ponto. Você perdeu.")
            break