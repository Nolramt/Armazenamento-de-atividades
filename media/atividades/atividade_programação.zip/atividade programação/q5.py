def classificar(peso, altura):
    if altura > 100:
        altura = altura/100
    imc = peso / (altura ** 2)
    if imc < 18.5:
        return "Abaixo"
    elif imc < 25:
        return "Normal"
    else:
        return "Acima"

while True:
    nome = input("Digite o nome: ")
    if nome == "FIM":
        break
    else:
        peso = float(input("Digite o peso: "))
        altura = float(input("Digite a altura: "))
        resultado = classificar(peso, altura)
    print(f"{nome}: {resultado}")