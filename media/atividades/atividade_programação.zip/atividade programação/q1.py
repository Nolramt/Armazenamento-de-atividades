vacinados = 0
recusados = 0

while True:
    idade = int(input("Digite a idade do paciente: "))
    if idade < 12 and idade >= 0:
        recusados += 1
        print("Só podem ser vacinadas pessoas com 12 anos ou mais!")
    elif idade < 0:
        break
    else:
        vacinados += 1
print(f"Vacinados: {vacinados}.  Recusados: {recusados}.")