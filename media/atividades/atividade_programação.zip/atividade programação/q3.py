tem_maior_que_a_media = True
lista = []
while True:
    valor_p = float(input("Digite o preço do produto: "))
    if valor_p > 0:
        lista.append(valor_p)
    else: break
media = sum(lista) / len(lista)
print(f"Média: {media}")
print("Produtos acima da média: ")
for i in range(len(lista)):
    if lista[i] > media:
        print(f"Produto {i+1} - R${lista[i]}")
        tem_maior_que_a_media = True
    else:
        tem_maior_que_a_media = False
if tem_maior_que_a_media == False:
    print("Nenhum")
        