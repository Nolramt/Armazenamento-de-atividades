Meia = 0
pago_meia = 0
Inteira = 0
pago_inteira = 0
while True:
    idade = int(input("Digite sua idade: "))
    if idade < 18 and idade > 0 or idade >= 60:
        Meia += 1
        pago_meia += 15
    elif idade >= 18 and idade < 60:
        
        Inteira += 1
        pago_inteira += 30
    else:
        break
print("Tipo----QTD----Valor")
print(f"Meia     {Meia}   R${pago_meia}")
print(f"Inteira  {Inteira}   R${pago_inteira}")
print(f"TOTAL   {Meia + Inteira}   R${pago_meia + pago_inteira}")