total_arrecadado = 0
while True:
    qnt_a_pagar = 0
    hrs = int(input("Digite quantas horas o carro ficou: "))
    if hrs > 1:
        if hrs > 6:
            qnt_a_pagar = 25
            total_arrecadado += qnt_a_pagar
        else:
            qnt_a_pagar += 5
            hrs -= 1
            qnt_a_pagar = qnt_a_pagar + (hrs * 2)
            total_arrecadado += qnt_a_pagar
    else:
            print("Horas invalidas!")
            break
print(f"Total arrecadado: {total_arrecadado}R$")